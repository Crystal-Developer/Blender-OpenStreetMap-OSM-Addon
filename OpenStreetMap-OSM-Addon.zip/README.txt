🗺Blender-OpenStreetMap-OSM-Addon OpenStreetMap

💾Installation It is recommended to use the latest official stable version of Blender from https://www.blender.org/download/.

Get the addon https://github.com/Crystal-Developer/Blender-OpenStreetMap-OSM-Addon Download. You will get a addon with the name io_import_scene_osm.py Do not open it!

⚙Install File → User Preferences... → Add-ons → Install... Find the io_import_scene_osm.py in your file system and press Install from File... button Enable the addon by checking the Enable Add-on.